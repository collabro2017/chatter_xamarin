// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "sqlite3.h"

int _tmain(int argc, _TCHAR* argv[])
{
  sqlite3 *db;
  if (sqlite3_open("sqlcipher.db", &db) == SQLITE_OK) {
    int i;
    
    sqlite3_key(db, "test123", 7);
    sqlite3_exec(db, "CREATE TABLE t1(a,b);", NULL, NULL, NULL);	
    sqlite3_exec(db, "BEGIN;", NULL, NULL, NULL);	
   
    for(i = 0; i < 1000; i++) {
      sqlite3_exec(db, "INSERT INTO t1(a,b) VALUES ('0123456789', '9876543210');", NULL, NULL, NULL);	
    }

    sqlite3_exec(db, "COMMIT;", NULL, NULL, NULL);	
   
    sqlite3_close(db);
  } else {
    printf("encountered error opening database");
  }
  return 0;
}
