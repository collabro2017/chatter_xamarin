﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Phone.Controls;
using Windows.Storage;
using SQLite;

namespace sqlcipher_windows_phone_demo
{
    public partial class MainPage : PhoneApplicationPage
    {
        private readonly String databasePath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "sqlcipher.db");
        private readonly SQLiteConnection connection;

        public MainPage()
        {
            InitializeComponent();
            connection = new SQLiteConnection(databasePath, "Password1!");
            connection.CreateTable<Note>();
            DisplayContent();
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            connection.Insert(new Note {Id = Guid.NewGuid().ToString(), Body = "one for the money"});
            connection.Insert(new Note {Id = Guid.NewGuid().ToString(), Body = "two for the show"});
            DisplayContent();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            connection.DeleteAll<Note>();
            DisplayContent();
        }

        private void DisplayContent()
        {
            var buffer = new StringBuilder();
            var notes = connection.Query<Note>("select * from note;");
            notes.ForEach(x => buffer.Append(String.Format("Id:{0} Body:{1}", x.Id, x.Body)));
            Content.Text = buffer.ToString();
        }
    }

    public class Note
    {
        public String Id { get; set; }
        public String Body { get; set; }
    }
}