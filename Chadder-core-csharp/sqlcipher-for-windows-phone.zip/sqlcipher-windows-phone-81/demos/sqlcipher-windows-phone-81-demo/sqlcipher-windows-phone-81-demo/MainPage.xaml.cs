﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Text;
using Windows.Storage;
using SQLite;

namespace sqlcipher_windows_phone_81_demo
{

    public sealed partial class MainPage : Page
    {
        private readonly String databasePath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "sqlcipher.db");
        private readonly SQLiteConnection connection;

        public MainPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Required;
            connection = new SQLiteConnection(databasePath, "Password1!");
            connection.CreateTable<Note>();
            DisplayContent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // TODO: Prepare page for display here.

            // TODO: If your application contains multiple pages, ensure that you are
            // handling the hardware Back button by registering for the
            // Windows.Phone.UI.Input.HardwareButtons.BackPressed event.
            // If you are using the NavigationHelper provided by some templates,
            // this event is handled for you.
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            connection.DeleteAll<Note>();
            DisplayContent();
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            connection.Insert(new Note { Id = Guid.NewGuid().ToString(), Body = "one for the money" });
            connection.Insert(new Note { Id = Guid.NewGuid().ToString(), Body = "two for the show" });
            DisplayContent();
        }

        private void DisplayContent()
        {
            var buffer = new StringBuilder();
            var notes = connection.Query<Note>("select * from note;");
            foreach (var note in notes)
            {
                buffer.Append(String.Format("Id:{0} Body:{1}", note.Id, note.Body));
            }
            Content.Text = buffer.ToString();
        }
    }

    public class Note
    {
        public String Id { get; set; }
        public String Body { get; set; }
    }
}
