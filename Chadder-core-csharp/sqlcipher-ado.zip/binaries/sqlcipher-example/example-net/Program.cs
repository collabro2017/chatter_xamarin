﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SQLite;

namespace example_net
{
    class Program
    {
        static void Main(string[] args)
        {
            DbProviderFactory provider = DbProviderFactories.GetFactory("System.Data.SQLite");
            using (DbConnection conn = provider.CreateConnection())
            {
                conn.ConnectionString = "Data Source=sqlcipher.db;Pooling=false;";
                ((SQLiteConnection)conn).SetPassword("test123");
                conn.Open();

                using (IDbCommand command = conn.CreateCommand())
                {
                    command.CommandText = "CREATE TABLE t1(a,b);";
                    command.ExecuteNonQuery();
                }

                using (DbTransaction transaction = conn.BeginTransaction())
                {
                    using (IDbCommand command = conn.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO t1(a,b) VALUES ('0123456789', '9876543210');";
                        command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
            }
        }
    }
}
