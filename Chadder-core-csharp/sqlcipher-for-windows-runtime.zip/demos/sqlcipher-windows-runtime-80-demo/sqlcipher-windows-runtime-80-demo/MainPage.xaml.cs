﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SQLite;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace sqlcipher_windows_runtime_80_demo
{
    public sealed partial class MainPage : Page
    {
        private readonly string databasePath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "sqlcipher.db");
        private readonly SQLiteConnection connection;

        public MainPage()
        {
            this.InitializeComponent();
            connection = new SQLiteConnection(databasePath, "Password1!");
            connection.CreateTable<Note>();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Run_Click(object sender, RoutedEventArgs e)
        {
            connection.Insert(new Note {Id = Guid.NewGuid().ToString(), Body = "one for the money"});
            connection.Insert(new Note {Id = Guid.NewGuid().ToString(), Body = "two for the show"});
            DisplayContent();
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            connection.DeleteAll<Note>();
            DisplayContent();
        }

        private void DisplayContent()
        {
            var buffer = new StringBuilder();
            var notes = connection.Query<Note>("select * from note;");
            foreach (var note in notes)
            {
                buffer.Append(String.Format("Id:{0} Body:{1}{2}", note.Id, note.Body, Environment.NewLine));
            }
            Content.Text = buffer.ToString();
        }
    }

    public class Note
    {
        public string Id { get; set; }
        public string Body { get; set; }
    }
}
